(()=>{

    let Yset=0;
    let currentSecNum=0;
    let sectionYset = 0;


    const sectionSet =[
        {
        
            height:0,
            hMultiple :5,
        
            obj :{
                container: document.querySelector('.section-0'),
                messageA: document.querySelector('.section-0-messageA'),
                messageB: document.querySelector('.section-0-messageB'),
                messageC: document.querySelector('.section-0-messageC'),   
                messageD: document.querySelector('.section-0-messageD')

            },

            val:{
                

            }
    
        },
        {
            height : 0,
            hMultiple : 3,

            obj: {
                container:document.querySelector('section-1')

            }
        },
    ];

    const setLayout = function(){

        if(innerHeight<500){
            sectionSet[0].height=3000;
            sectionSet[1].height=3000;

            sectionSet[0].obj.container.style.height = `${sectionSet[0].height}px`;
            sectionSet[1].obj.container.style.height = `${sectionSet[1].height}px`;
        }else{
            for(let i=0; i<sectionSet.length; i++){
                
            }
        }
    }

    const setBodyID = function(section)
    {
        document.body.setAttribute('id', `show-section${section}`);
    }

    const getCurrentSection = function()
    {
        let section=0;

        let getHigh =[
            sectionSet[0].height,
            sectionSet[0].height+sectionSet[1].height
        ];

        if(Yset <= getHigh[0]){
            section=0;
        }else if ((Yset>getHigh[0])&&(Yset<=getHigh[1])){
            section=1;
        }

        return section;
    }


    const getPrevSectionHeight = function()
    {
        let prevHeight = 0;

        for(let i=0; i<currentSecNum; i++){
            prevHeight=prevHeight+sectionSet[i].height;
        }

        return prevHeight;
    }


    const calRate = function(val){
        let result=0;
        let rate = 0;
        const height = sectionSet[currentSecNum].height;

        let partStart =0;
        let partEnd =0;
        let partHeight=0;

        if(val.length===2){
            rate =sectionYset/height;

            result=(rate*(val[1]-val[0]))+val[0];
        }
        else if(val.length===3){
            partStart=val[2].start*height

            partEnd=val[2].end*height;

            partHeight=partEnd-partStart;
        

        if(sectionYset<partStart){
            result=val[0];
        }
        else if(sectionYset>partEnd){
            result=val[1];
        }
        else{
            rate =(sectionYset-partStart)/partHeight;
            result=(rate*(val[1]-val[0]))+val[0];
        }
    }
        return result;
    }

    const playFade = function(){
        
    }


    ////////////////////////////////
    window.addEventListener('scroll', ()=>{

        Yset=window.scrollY;

        currentSecNum=getCurrentSection();
        sectionYset=Yset-getPrevSectionHeight();

        setBodyID(currentSecNum);

        playFade;


    } );

    window.addEventListener('load', ()=>{
        setLayout();
    
    } 
    );



})();