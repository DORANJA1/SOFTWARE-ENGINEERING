package DBPKG;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	public static Connection getConnection() throws Exception {
		Class.forName("oracle.jdbc.OracleDriver");
		
		Connection conn = DriverManager.getConnection
				("jdbc:oracle:thin:@//localhost:1521/xe", "SYSTEM", "1234");
		
		return conn;
		
	}

}
